package ai.gravityfield.gravity_sdk.utils

import java.lang.ref.WeakReference

/** UI-thread state for one SDK-owned presentation. Completion follows physical dismissal. */
internal class InAppPresentation(
    private val performDismiss: (complete: (Boolean) -> Unit) -> Unit,
    private val didDismiss: (Boolean) -> Unit,
) {
    /** Replaced by the next step of the same showing: dismiss without reporting a close. */
    var replaced = false
    private var closing = false
    private var result: Boolean? = null

    fun close(completion: (Boolean) -> Unit = {}) {
        if (result != null || closing) { completion(false); return }
        closing = true
        performDismiss { success ->
            if (result == null) {
                result = success
                didDismiss(success)
                completion(success)
            }
        }
    }
}

/** Weak references keep externally removed UI from being retained by the SDK. */
internal class InAppPresentationRegistry {
    private data class Entry(
        val presentation: WeakReference<InAppPresentation>,
        val campaignId: String?,
        val coversScreen: Boolean,
        val isShowing: () -> Boolean,
    ) {
        fun get() = presentation.get()
    }
    private val entries = mutableMapOf<String, Entry>()
    fun contains(contentId: String) = entries[contentId]?.let { it.get() != null && it.isShowing() } == true
    fun containsCampaign(campaignId: String) = entries.values.any { it.campaignId == campaignId && it.get() != null && it.isShowing() }
    /** A modal, fullscreen or bottom sheet is open; snackbars do not cover the screen. */
    fun containsScreenCover() = entries.values.any { it.coversScreen && it.get() != null && it.isShowing() }
    /** Any SDK in-app, including a snackbar, is open. */
    fun containsAny() = entries.values.any { it.get() != null && it.isShowing() }
    fun register(
        presentation: InAppPresentation,
        contentId: String,
        campaignId: String? = null,
        coversScreen: Boolean = true,
        isShowing: () -> Boolean = { true },
    ) {
        entries.entries.removeAll { it.value.get() == null }
        entries[contentId] = Entry(WeakReference(presentation), campaignId, coversScreen, isShowing)
    }
    fun remove(presentation: InAppPresentation?, contentId: String) {
        if (entries[contentId]?.get() === presentation) entries.remove(contentId)
    }
    fun dismiss(contentId: String, completion: (Boolean) -> Unit) {
        val presentation = entries[contentId]?.get()
        if (presentation == null) { entries.remove(contentId); completion(false) }
        else presentation.close(completion)
    }
}
