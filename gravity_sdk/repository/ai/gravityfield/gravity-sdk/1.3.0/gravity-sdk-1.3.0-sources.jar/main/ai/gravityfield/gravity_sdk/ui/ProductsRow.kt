package ai.gravityfield.gravity_sdk.ui

import ai.gravityfield.gravity_sdk.GravitySDK
import ai.gravityfield.gravity_sdk.extensions.conditional
import ai.gravityfield.gravity_sdk.models.CampaignContent
import ai.gravityfield.gravity_sdk.models.Element
import ai.gravityfield.gravity_sdk.models.Slot
import ai.gravityfield.gravity_sdk.network.Campaign
import ai.gravityfield.gravity_sdk.utils.ProductEventService
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.unit.dp

@Composable
internal fun ProductsRow(
    element: Element,
    slots: List<Slot>,
    content: CampaignContent,
    campaign: Campaign,
) {
    // No products: no height, margin, padding or background strip, as on iOS/Flutter.
    if (slots.isEmpty()) return
    val style = element.style
    val presentationAnalytics = LocalPresentationAnalytics.current
    val height = style.size?.height
    val margin = style.margin
    val paddingValues = if (style.padding != null)
        PaddingValues(
            start = style.padding.left.dp,
            top = style.padding.top.dp,
            end = style.padding.right.dp,
            bottom = style.padding.bottom.dp
        )
    else PaddingValues(horizontal = 16.dp)
    val rowSpacing = style.rowSpacing?.dp ?: 8.dp

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .conditional(margin != null) {
                padding(
                    start = margin!!.left.dp,
                    top = margin.top.dp,
                    end = margin.right.dp,
                    bottom = margin.bottom.dp
                )
            }
            // As on iOS/Flutter, height is the outer box including padding; the background
            // fills it and products never draw over neighbouring elements.
            .conditional(height != null) {
                height(height!!.dp)
            }
            .conditional(style.backgroundColor != null) {
                background(color = style.backgroundColor!!)
            }
            .clipToBounds()
    ) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .conditional(height != null) { fillMaxHeight() },
            contentPadding = paddingValues,
            horizontalArrangement = Arrangement.spacedBy(rowSpacing)
        ) {
            items(slots.size) { index ->
                val slot = slots[index]
                VisibilityDetector(
                    onVisible = {
                        if (presentationAnalytics?.shouldReportRowProduct(slot) != false) {
                            ProductEventService.instance.sendProductVisibleImpression(
                                slot,
                                content,
                                campaign
                            )
                        }
                    }
                ) {
                    if (GravitySDK.instance.productViewBuilder != null) {
                        GravitySDK.instance.productViewBuilder!!.Build(slot, content, campaign)
                    } else {
                        GravityProduct(slot)
                    }
                }
            }
        }
    }
}
